package com.kosan.lat2_akb11_10116466_estertambunan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class LoginApps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_apps);
    }

    public void OnClick(View view) {
        Intent i = null;
        switch (view.getId()) {
            case R.id.btn_regis:
                i = new Intent(this, Register.class);
                break;
        }
        if (null != i) startActivity(i);
    }
}