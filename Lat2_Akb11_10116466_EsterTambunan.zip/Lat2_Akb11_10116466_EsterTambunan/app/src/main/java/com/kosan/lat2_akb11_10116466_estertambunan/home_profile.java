package com.kosan.lat2_akb11_10116466_estertambunan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class home_profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_profile);
    }
}
