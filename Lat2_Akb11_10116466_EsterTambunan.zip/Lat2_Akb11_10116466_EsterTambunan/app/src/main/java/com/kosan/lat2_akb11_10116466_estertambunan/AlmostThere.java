package com.kosan.lat2_akb11_10116466_estertambunan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AlmostThere extends AppCompatActivity {
    Button kever;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_almost_there);
        kever = (Button) findViewById(R.id.btn_verifyalmostthere);
        kever.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AlmostThere.this, Verification.class);
                startActivity(i);
            }
        });
    }
}